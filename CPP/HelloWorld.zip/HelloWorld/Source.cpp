#include <stdio.h>

int main() {
	printf("Whatever, this app works in this computer too! Yay!!\n");
	getchar();
	return 0;
}